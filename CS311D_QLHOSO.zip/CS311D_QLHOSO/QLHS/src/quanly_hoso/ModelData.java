/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanly_hoso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author duong
 */
public class ModelData extends AbstractTableModel{
     ArrayList<HOSO> data;
     String colNames[] = {"Mã hồ sơ", "Họ tên", "Số CMND", "Ngày sinh"};
     Class<?> colClass[] = {String.class, String.class, Long.class, String.class};

    public ModelData() {
        data = new ArrayList<>();
    }

    ModelData(ArrayList<HOSO> list) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        data = list;
    }
     
    @Override
    public int getRowCount() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return data.size();
    }

    @Override
    public int getColumnCount() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return colNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyy");
        switch(columnIndex) {
            case 0:
                return data.get(rowIndex).getMaHoSo();
            case 1:
                return data.get(rowIndex).getHoTen();
            case 2:
                return data.get(rowIndex).getSoCMND();
            case 3:
                return df.format(data.get(rowIndex).getNgaySinh());
        }
         return null;
    }
    
     @Override
    public String getColumnName(int columnIndex) {
        return colNames[columnIndex];
    }
    
     @Override
    public Class<?> getColumnClass(int columnIndex) {
        return colClass[columnIndex];
    }
    
     @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }
}
