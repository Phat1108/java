/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlyphong;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author PC
 */
public class ModelData extends AbstractTableModel{
    ArrayList<PHONG> data;
    String colNames[] = {"Mã phòng","Ngày thuê","Hạng","Ngày trả","Đơn giá","Thành tiền"};
    Class<?> colClasses[] = {String.class, String.class,String.class, String.class,Double.class, Double.class};

    public ModelData() {
    }

    public ModelData(ArrayList<PHONG> data) {
        this.data = data;
    }

    @Override
    public int getRowCount() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return data.size();
    }

    @Override
    public int getColumnCount() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return colNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        switch(columnIndex) {
            case 0:
                return data.get(rowIndex).getMaPhong();
            case 1:
                return data.get(rowIndex).getHangPhong();
            case 2:
                return data.get(rowIndex).getNgayThue();
            case 3:
                return data.get(rowIndex).getNgayTra();
            case 4:
                return data.get(rowIndex).getDonGia();
            case 5:
                return data.get(rowIndex).tinhTienThue();
        }
        return null;
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return colNames[columnIndex];
    }
    
    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return colClasses[columnIndex];
    }
    
    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }
}
