
package quanlyphong;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author PC
 */
public class PHONG implements IPHONG {

    protected String maPhong;
    protected String hangPhong;
    protected Date ngayThue;
    protected Date ngayTra;
    protected double donGia;

    public PHONG() {
    }

    public PHONG(String maPhong, String hangPhong, Date ngayThue, Date ngayTra, double donGia) {
        this.maPhong = maPhong;
        this.hangPhong = hangPhong;
        this.ngayThue = ngayThue;
        this.ngayTra = ngayTra;
        this.donGia = donGia;
    }

    public String getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(String maPhong) {
        this.maPhong = maPhong;
    }

    public String getHangPhong() {
        return hangPhong;
    }

    public void setHangPhong(String hangPhong) {
        this.hangPhong = hangPhong;
    }

    public Date getNgayThue() {
        return ngayThue;
    }

    public void setNgayThue(Date ngayThue) {
        this.ngayThue = ngayThue;
    }

    public Date getNgayTra() {
        return ngayTra;
    }

    public void setNgayTra(Date ngayTra) {
        this.ngayTra = ngayTra;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public int SoNgayThue() {
        int soNgayThue = 0;
        Calendar c1= new GregorianCalendar();
        Calendar c2= new GregorianCalendar();
        c1.setTime(ngayThue);
        c2.setTime(ngayTra);
        if(c1.get(Calendar.DATE)==c2.get(Calendar.DATE)){
            return 1;
        }else{
            return c2.get(Calendar.DATE)-c1.get(Calendar.DATE);
        }
    }

    @Override
    public double tinhTienThue() {
        return donGia * SoNgayThue();
    }

}
