/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlyphong;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author PC
 */
public class PHONGHOP extends PHONG{

    protected int soGhe;

    public PHONGHOP() {
    }

    public PHONGHOP(int soGhe) {
        this.soGhe = soGhe;
    }

    public PHONGHOP(int soGhe, String maPhong, String hangPhong, Date ngayThue, Date ngayTra, double donGia) {
        super(maPhong, hangPhong, ngayThue, ngayTra, donGia);
        this.soGhe = soGhe;
    }

    public int getSoGhe() {
        return soGhe;
    }

    public void setSoGhe(int soGhe) {
        this.soGhe = soGhe;
    }
    
}
