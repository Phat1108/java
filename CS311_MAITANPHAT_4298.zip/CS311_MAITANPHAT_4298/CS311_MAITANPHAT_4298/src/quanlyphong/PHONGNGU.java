/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlyphong;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author PC
 */
public class PHONGNGU extends PHONG {

    protected int soGiuong;

    public PHONGNGU() {
    }

    public PHONGNGU(int soGiuong) {
        this.soGiuong = soGiuong;
    }

    public PHONGNGU(int soGiuong, String maPhong, String hangPhong, Date ngayThue, Date ngayTra, double donGia) {
        super(maPhong, hangPhong, ngayThue, ngayTra, donGia);
        this.soGiuong = soGiuong;
    }

    public int getSoGiuong() {
        return soGiuong;
    }

    public void setSoGiuong(int soGiuong) {
        this.soGiuong = soGiuong;
    }

}
