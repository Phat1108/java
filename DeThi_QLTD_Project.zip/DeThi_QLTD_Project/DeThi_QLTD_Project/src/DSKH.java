
import java.util.ArrayList;


public class DSKH {
    ArrayList<KhachHang> arr=new ArrayList<>();
    //them
    public boolean themVaoDS(KhachHang kh){
    return  arr.add(kh);
    }
    public boolean  xoatheoMaKH(String maKH){
        for (KhachHang kh : arr) {
            if (kh.getMaKH().equalsIgnoreCase(maKH.trim())) {
                arr.remove(kh);
                return true;
            }
        }
        return  false;
    }
    public KhachHang timTheoMaKH(String maKH){
        for (KhachHang kh : arr) {
            if (kh.getMaKH().equalsIgnoreCase(maKH)) {
                return  kh;               
            }           
        }
        return null;
    }
    public double tinhTongSLTheoLoaiKH(String loaiKH){
    double tong=0;
        if (loaiKH.equalsIgnoreCase("KHVN")) {
            for (KhachHang kh : arr) {
                if (kh instanceof KHVN) {
                    KHVN khvn=(KHVN) kh;
                    tong+=khvn.getSoLuong();
                }
            }           
        }
        if (loaiKH.equalsIgnoreCase("KHNN")) {
            for (KhachHang kh : arr) {
                if (kh instanceof KHNN) {
                    KHNN khnn=(KHNN) kh;
                    tong+=khnn.getSoLuong();
                }
            }    
        }
        return  tong;
    }
    

    Iterable<KhachHang> layDS() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
