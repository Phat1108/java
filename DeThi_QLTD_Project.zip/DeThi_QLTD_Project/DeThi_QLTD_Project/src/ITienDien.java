
public interface ITienDien {
    double tinhThanhTien();
    
}
