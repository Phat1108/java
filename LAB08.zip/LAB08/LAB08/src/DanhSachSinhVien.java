
import java.util.ArrayList;


public class DanhSachSinhVien {
    ArrayList<SinhVien> arr=new ArrayList<>();
    public boolean themVaoDS(SinhVien sv){
        return arr.add(sv);
        
    }
    public ArrayList<SinhVien> layDS(){
        return arr;
    }
    public boolean xoaTheoMaSV(String maSV){
        for (SinhVien sv : arr) {
            if(sv.getMaSV().equalsIgnoreCase(maSV.trim())){
                arr.remove(sv);
                return true;
        }

        }
        return false;
    }
    public SinhVien timTheoMaSV(String maSV){
        for (SinhVien sv : arr) {
            if(sv.getMaSV().equalsIgnoreCase(maSV.trim())){
                return sv;
            }
}
    return null;
    }
}
