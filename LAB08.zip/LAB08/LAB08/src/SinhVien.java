
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Boy
 */
public class SinhVien {
    private String maSV,nganhHoc,hoTen;
    private Date ngaySinh;
    private boolean gioiTinh;
    private float dtb;

    public SinhVien() {
    }

    public SinhVien(String maSV, String hoTen, Date ngaySinh, String nganhHoc, boolean gioiTinh, float dtb) {
        this.maSV = maSV;
        this.nganhHoc = nganhHoc;
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
        this.gioiTinh = gioiTinh;
        this.dtb = dtb;
    }

    public String getMaSV() {
        return maSV;
    }

    public void setMaSV(String maSV) {
        this.maSV = maSV;
    }

    public String getNganhHoc() {
        return nganhHoc;
    }

    public void setNganhHoc(String nganhHoc) {
        this.nganhHoc = nganhHoc;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public Date getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(Date ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public boolean isGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(boolean gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public float getDtb() {
        return dtb;
    }

    public void setDtb(float dtb) {
        this.dtb = dtb;
    }
    public String xeploai(){
        if(dtb>=8){
            return "gioi";
        }else if(dtb>=7){
            return "kha";
    }else if(dtb>=5){
        return "tb";
    }else{
        return "yeu";
    }
    }
}
