/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanly_hoso;

import java.util.ArrayList;

/**
 *
 * @author duong
 */
public class DSHS {
    private ArrayList<HOSO> list;

    public DSHS() {
        list = new ArrayList<>();
    }

    public ArrayList<HOSO> getList() {
        return list;
    }

    public void setList(ArrayList<HOSO> list) {
        this.list = list;
    }
    
    public void Them(HOSO nv) {
        list.add(nv);
    }
    public void Xoa(String maHoSo) {
        for (HOSO hoso : list) {
            if (hoso.getMaHoSo().equalsIgnoreCase(maHoSo)) {
                list.remove(hoso);
                return;
            }
        }
    }

    public void CapNhat(HOSO maHoSo) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getMaHoSo().equalsIgnoreCase(maHoSo.getMaHoSo())) {
                list.set(i, maHoSo);
                return;
            }
        }
    }

    public HOSO TimKiem(String maHoSo) {
        for (HOSO hoSo : list) {
            if (hoSo.getMaHoSo().equalsIgnoreCase(maHoSo)) {
                return hoSo;
            }
        }
        return null;
    }
    
}
