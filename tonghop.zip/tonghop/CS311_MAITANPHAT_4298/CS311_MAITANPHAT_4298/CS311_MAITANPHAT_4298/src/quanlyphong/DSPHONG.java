/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlyphong;

import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class DSPHONG {

    ArrayList<PHONG> list;

    public DSPHONG(ArrayList<PHONG> list) {
        this.list = list;
    }

    public DSPHONG() {
        list = new ArrayList<>();
    }

    public ArrayList<PHONG> getList() {
        return list;
    }

    public void setList(ArrayList<PHONG> list) {
        this.list = list;
    }

    public void Them(PHONG phong) {
        list.add(phong);
    }

    public void Xoa(String maPhong) {
        for (PHONG phong : list) {
            if (phong.getMaPhong().equalsIgnoreCase(maPhong)) {
                list.remove(phong);
                return;
            }
        }
    }

    public void CapNhat(PHONG phong) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getMaPhong().equalsIgnoreCase(phong.getMaPhong())) {
                list.set(i, phong);
                return;
            }
        }
    }

    public PHONG TimKiem(String maPhong) {
        for (PHONG Phong : list) {
            if (Phong.getMaPhong().equalsIgnoreCase(maPhong)) {
                return Phong;
            }
        }
        return null;
    }

    public ArrayList<PHONG> TimTheoHang(String hang) {
        ArrayList<PHONG> hp = new ArrayList<>();
        for (PHONG phong : list) {
            if (phong.getHangPhong().equalsIgnoreCase(hang)) {
                hp.add(phong);
            }
        }
        return hp;
    }

    public double TinhTongTien() {
        double tong = 0;
        for (PHONG phong : list) {
            tong += phong.tinhTienThue();
        }
        return tong;
    }
}
