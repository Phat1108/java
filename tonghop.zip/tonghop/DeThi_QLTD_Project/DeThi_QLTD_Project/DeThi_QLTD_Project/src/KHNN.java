
import java.util.Date;

public class KHNN extends KhachHang {

    private String quocTich;

    public KHNN() {
    }

    public KHNN(String quocTich, String maKH, String hoTen, Date ngayRaHD, double soLuong, double donGia) {
        super(maKH, hoTen, ngayRaHD, soLuong, donGia);
        this.quocTich = quocTich;
    }

    public String getQuocTich() {
        return quocTich;
    }

    public void setQuocTich(String quocTich) {
        this.quocTich = quocTich;
    }

    @Override
    public double tinhThanhTien() {
        return soLuong * donGia;

    }

}
