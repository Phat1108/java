
import java.util.Date;


public class KHVN extends KhachHang{
    private int dinhMuc;
    private String doiTuong;

    public KHVN() {
    }

    public KHVN(int dinhMuc, String doiTuong, String maKH, String hoTen, Date ngayRaHD, double soLuong, double donGia) {
        super(maKH, hoTen, ngayRaHD, soLuong, donGia);
        this.dinhMuc = dinhMuc;
        this.doiTuong = doiTuong;
    }

    public int getDinhMuc() {
        return dinhMuc;
    }

    public void setDinhMuc(int dinhMuc) {
        this.dinhMuc = dinhMuc;
    }

    public String getDoiTuong() {
        return doiTuong;
    }

    public void setDoiTuong(String doiTuong) {
        this.doiTuong = doiTuong;
    }

    @Override
    public double tinhThanhTien() {
        if (soLuong<=dinhMuc) {
            return soLuong*donGia;
        } else {
            return (soLuong*donGia*dinhMuc)+(soLuong-dinhMuc)*donGia*2.5;
        }
    }
    
}
