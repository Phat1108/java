
import java.util.Date;

public class BNNoiTru extends BenhNhan {

    private double phiNgay;
    private Date ngayRaVien;

    public BNNoiTru() {
    }

    public BNNoiTru(double phiNgay, Date ngayRaVien, String ma, String hoTen, Date ngayVaoVien, double tienThuoc) {
        super(ma, hoTen, ngayVaoVien, tienThuoc);
        this.phiNgay = phiNgay;
        this.ngayRaVien = ngayRaVien;
    }

    public double getPhiNgay() {
        return phiNgay;
    }

    public void setPhiNgay(double phiNgay) {
        this.phiNgay = phiNgay;
    }

    public Date getNgayRaVien() {
        return ngayRaVien;
    }

    public void setNgayRaVien(Date ngayRaVien) {
        this.ngayRaVien = ngayRaVien;
    }

    public double phiThuoc() {
        return tienThuoc * soNgayNamVien();
    }

    @Override
    public double vienPhi() {
        return phiNgay * soNgayNamVien() + phiThuoc();
    }

    public int soNgayNamVien() {
        //getTime()
        long soGiay = ngayRaVien.getTime() - ngayVaoVien.getTime();
        int soNgay = (int) soGiay / (24 * 60 * 60 * 1000);
        return soNgay;
    }

}
