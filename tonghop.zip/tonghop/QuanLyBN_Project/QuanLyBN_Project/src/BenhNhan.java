
import java.util.Date;

public abstract class BenhNhan implements IBenhNhan{
    protected  String ma, hoTen;
    protected  Date ngayVaoVien;
    protected  double  tienThuoc;

    public BenhNhan() {
    }

    public BenhNhan(String ma, String hoTen, Date ngayVaoVien, double tienThuoc) {
        this.ma = ma;
        this.hoTen = hoTen;
        this.ngayVaoVien = ngayVaoVien;
        this.tienThuoc = tienThuoc;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public Date getNgayVaoVien() {
        return ngayVaoVien;
    }

    public void setNgayVaoVien(Date ngayVaoVien) {
        this.ngayVaoVien = ngayVaoVien;
    }

    public double getTienThuoc() {
        return tienThuoc;
    }

    public void setTienThuoc(double tienThuoc) {
        this.tienThuoc = tienThuoc;
    }
    
    
}
