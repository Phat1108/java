
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

public class DSBenhNhan {

    ArrayList<BenhNhan> arr = new ArrayList<>();

    public boolean themVaoDS(BenhNhan bn) {
        return arr.add(bn);
    }

    public boolean xoaBNNoiTru(Date ngayChiDinh) {
        Iterator<BenhNhan> it = arr.iterator();
        while (it.hasNext()) {
            BenhNhan next = it.next();
            if (next instanceof BNNoiTru) {
                BNNoiTru bnnt = (BNNoiTru) next;
                if (bnnt.getNgayRaVien().compareTo(ngayChiDinh) < 0) {
                    arr.remove(bnnt);
                    return true;
                }
            }
//        for (BenhNhan bn : arr) {
//            if (bn instanceof BNNoiTru) {
//                BNNoiTru bnnt = (BNNoiTru) bn;
//                if (bnnt.getNgayRaVien().compareTo(ngayChiDinh) < 0) {
//                    arr.remove(bnnt);
//                  
//                    return true;
//                }
//            }
//        }
//       
        }
         return false;
    }

    public double tinhTongVienPhi() {
        double tong = 0;
        for (BenhNhan bn : arr) {
            tong += bn.vienPhi();
        }
        return tong;
    }

    public double abc() {
        return 0;
    }

    public BenhNhan timTheoMaBN(String maBN) {
        for (BenhNhan bn : arr) {
            if (bn.getMa().equalsIgnoreCase(maBN.trim())) {
                return bn;
            }
        }
        return null;
    }

    public ArrayList<BenhNhan> layDSBNNgoaiTru() {
        ArrayList<BenhNhan> dsMoi = new ArrayList<>();
        for (BenhNhan bn : arr) {
            if (bn instanceof BNNgoaiTru) {
                BNNgoaiTru bnnt = (BNNgoaiTru) bn;
                dsMoi.add(bnnt);
            }
        }
        return dsMoi;
    }
}
